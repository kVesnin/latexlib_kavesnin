# LaTeX Library of Kostya

A simple Python library for homework 2 of masters program's python course.